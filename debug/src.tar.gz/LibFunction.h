#include <stdlib.h>
#ifndef _LF_H_
#define _LF_H_
#define malloc
void* malloc_s(size_t size);
#endif

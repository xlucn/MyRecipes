#include "NumericalRecipes.h"
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{

    if (argc == 2 && strcmp(argv[1], "testall") == 0)
    {
        testall();
    }
    else if(testNewtonMethod())
    {
        printf("test failed\n");
    }

    return 0;
}
